# Multiple Choice

# Return the answer to the multiple choice question in the handout.
# If you think option c is the correct answer,
# return 'c'

def question_1():
    return 'b'
    #### To understand this, recall the vertical representation in the lecture slides.


def question_2():
    return 'd'


def question_3():
    return 'b'


def question_4():
    return 'a'


def question_5():
    return 'a'
